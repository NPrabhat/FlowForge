package com.forge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
